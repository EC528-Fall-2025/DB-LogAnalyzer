#!/usr/bin/env bash
set -euo pipefail

# Use your ARM-native FoundationDB image
IMAGE="fdb-arm:7.3.63"
LOGDIR="${LOGDIR:-$PWD/simlogs}"
mkdir -p "$LOGDIR"

# --- Parse args: copy each -f file into /work and rewrite path ---
args_out=()
files_to_copy=()

while [[ $# -gt 0 ]]; do
  case "${1:-}" in
    -f)
      [[ $# -ge 2 ]] || { echo "error: -f needs a file" >&2; exit 2; }
      host_file="$2"
      [[ -f "$host_file" ]] || { echo "error: not found: $host_file" >&2; exit 2; }
      base="$(basename "$host_file")"
      files_to_copy+=("$host_file::$base")
      args_out+=("-f" "/work/$base")
      shift 2
      ;;
    *)
      args_out+=("$1")
      shift
      ;;
  esac
done

# Choose container name
CONTAINER_NAME="fdb-sim"

# Correct reuse logic: only reuse if RUNNING
if docker ps --format '{{.Names}}' | grep -qx "${CONTAINER_NAME}"; then
    echo "Reusing running container: ${CONTAINER_NAME}"
    CID="${CONTAINER_NAME}"
else
    echo "Creating new container: ${CONTAINER_NAME}"
    CID="$(docker create --name "$CONTAINER_NAME" "$IMAGE" sleep infinity)"
    docker start "$CID"
fi

# Prepare work directories
docker exec "$CID" sh -lc 'mkdir -p /work /var/fdb/logs'

# Copy TOML spec file(s)
for spec in "${files_to_copy[@]}"; do
  host="${spec%%::*}"
  base="${spec##*::}"
  docker cp "$host" "$CID:/work/$base"
done

# Add logdir (if user didn't specify)
if printf '%s\0' "${args_out[@]}" | grep -qzx -- '--logdir'; then
  :
else
  args_out+=(--logdir "/var/fdb/logs")
fi

# Run fdbserver simulation inside container (non-interactive)
docker exec "$CID" sh -lc "
  set -e
  exec \"\$(command -v fdbserver)\" ${args_out[*]@Q}
"

# Copy logs back to host
docker cp "$CID:/var/fdb/logs/." "$LOGDIR/" 2>/dev/null || true

echo "Logs copied to: $LOGDIR"
